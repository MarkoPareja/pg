/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cat.institutmvm.app;

import cat.institutmvm.ui.MyFrame;
import javax.swing.JFrame;
/**
 * 
 * @author marko
 */
public class main {
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        MyFrame efrm = new MyFrame();
        efrm.setVisible(true);
        efrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
    }
    public void run() {
        MyFrame frame = new MyFrame();
        frame.setVisible(true);
    }
}
